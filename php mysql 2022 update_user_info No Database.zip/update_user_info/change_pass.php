<?php
session_start();
// Database Connection with mysql database
$connect = mysqli_connect("localhost", "root", "", "update_db");

$id=$_SESSION['id'];

if(isset($_POST['cng_btn']))
{
 $cur_pass=($_POST['cur_pass']);
 $new_pass=($_POST['new_pass']);
 
$sql=mysqli_query($connect,"SELECT password FROM user_info where password='$cur_pass' && id='$id'");
$num=mysqli_fetch_array($sql);

if($num>0)
{
 $con=mysqli_query($connect,"update user_info set password='$new_pass' where id='$id'");
$_SESSION['msg1']="Password Changed Successfully !!";
}
else
{
$_SESSION['msg1']="Old Password not match !!";
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="log.css">
    <title>Change Password</title>
</head>
<body>

    <div class="container">
    <a href="logout.php"><button>Logout</button></a>
        <h2 class="title1">Change Password</h2>
		<p style="color:red;"><?php echo $_SESSION['msg1']="";?></p>
        <br>
        <form method="post">
            <div class="mb-3" id="fieldDiv">
              <label>Current Password</label>
              <input type="text" name="cur_pass" >
            </div>
            <br>
            <div class="mb-3" id="fieldDiv">
              <label>New Password</label>
              <input type="password" name="new_pass">
            </div>
            <br>

            <br>
            <button type="submit" name="cng_btn" id="logBtn" class="btn btn-primary">Change Password</button>
			<br>
            <a href="user_dashboard.php">Back</a>
          </form>
    </div>
    

    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>