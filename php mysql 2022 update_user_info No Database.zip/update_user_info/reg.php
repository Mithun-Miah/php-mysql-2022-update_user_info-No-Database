<?php
session_start();

$connect = mysqli_connect('localhost', 'root','','update_db');
if($connect){
  //echo "Conn Success";
}else{
  echo "Conn Unsuccess";
}

if(isset($_POST['reg_btn'])){
  $name = $_POST['full_name'];
  $f_name = $_POST['f_name'];
  $m_name = $_POST['m_name'];
  $email = $_POST['email'];
  $password = $_POST['password'];

  if($email == "" || $password == ""){
    echo "<script>alert('Please Fillup All Information Correctly')</script>";
  }else{
    $insertData = "insert into user_info(full_name,f_name,m_name,email,password) 
            values('$name','$f_name','$m_name','$email','$password')";
  
    $query = mysqli_query($connect,$insertData);

    if($query){
      echo "<script>alert('Registration Success')</script>";
    }else{
      echo "<script>alert('Registration Failed')</script>";
    }
  }

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="reg.css">
    <title>Registration Window</title>

    <style>
      #logBtn{
        border: none;
        background-color: blue;
        text-decoration:none;
        color: white;
        padding: 15px;
        font-weight: 800;
        border-radius: 10px;
        margin: auto;
        display: block;
        transition: 0.2s step-end;
        cursor: pointer;
      }
      #logBtn:hover{
          background-color: yellowgreen;
          color: white;
      }
    </style>
</head>
<body>

    <div class="container">
        <h2 class="title1">Registration Form</h2>
        <br>
        <form method="post">
            <div class="mb-3" id="fieldDiv">
                <label for="exampleInputEmail1" class="form-label">Full Name</label>
                <input type="text" name="full_name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
              </div>
              <br>
              <div class="mb-3" id="fieldDiv">
                <label for="exampleInputEmail1" class="form-label">Father's Name</label>
                <input type="text" name="f_name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
              </div>
              <br>
              <div class="mb-3" id="fieldDiv">
                <label for="exampleInputEmail1" class="form-label">Mother's Name</label>
                <input type="text" name="m_name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
              </div>
              <br>
            <div class="mb-3" id="fieldDiv">
              <label for="exampleInputEmail1" class="form-label">Email address</label>
              <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
              <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
            </div>
            <br>
            <div class="mb-3" id="fieldDiv">
              <label for="exampleInputPassword1" class="form-label">Password</label>
              <input type="password" name="password" class="form-control" id="exampleInputPassword1">
            </div>
            <br>
            <button type="submit" name="reg_btn" id="regBtn" class="btn btn-primary">Registration</button>
          </form>
          <div>
            <a href="log.php"><button type="submit" id="logBtn" class="btn btn-primary">Login</button></a>
          </div>
    </div>
    

    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>