<?php
// For Store data
session_start();

$msg=$name=$ad_id=$email= "";

$connect = mysqli_connect('localhost', 'root', '', 'update_db');
if($connect){
    //echo "<script>alert('DB Connection Success')</script>";
}else{
    echo "<script>alert('DB Connection Failed')</script>";
}
// For Secure URL / do not permission enter by url type
if($_SESSION['email'] == true){
    // after login fetch email address and password display from database into this page
    $msg = "$_SESSION[email]";
    //$msg3 = "Email : $_SESSION[email]";
} else{
    header('Location: log.php');
}

$full_name = "";
$f_name = "";
$m_name = "";
$email = "";
$password = "";

$query = "select * from user_info";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="reg.css">
    <title>User Info View Window</title>
</head>
<body>

    <div class="container">
    <a href="logout.php"><button>Logout</button></a>
        <h2 class="title1">Profile View</h2>
        <br>
        <form action="">
                        <table class="table-bordered" style="width:100%;text-align:center;border:1px solid;">
                            <tr style="text-align:center;">
                                <th>Full Name</th>
                                <th>Father's Name</th>
                                <th>Mother's Name</th>
                                <th>Email Address</th>
                                <th>Password</th>
                            </tr>

                            <?php
                                $query_run = mysqli_query($connect,$query);
                                while($row = mysqli_fetch_array($query_run)){
                                    $full_name = $row['full_name'];
                                    $f_name = $row['f_name'];
                                    $m_name = $row['m_name'];
                                    $email = $row['email'];
                                    $password = $row['password'];
                                    ?>
                                    <tr>
                                        <td><?php echo $full_name; ?></td>
                                        <td><?php echo $f_name; ?></td>
                                        <td><?php echo $m_name; ?></td>
                                        <td><?php echo $email; ?></td>
                                        <td><?php echo $password; ?></td>
                                    </tr>
                            <?php
                            }
                            ?>

                        </table>
                        <br>
                        <a href="user_dashboard.php">Back</a>
                    </form>
    </div>
    

    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>