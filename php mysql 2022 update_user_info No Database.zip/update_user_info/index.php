<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <title>Primary Window</title>
</head>
<body>

    <div class="container">
        <h2 class="title1">Primary Window</h2>
        <br>
        <div class="buttonDiv">
            <a href="reg.php"><button type="submit" id="logBtn" class="btn btn-primary">Registration</button></a>
            <a href="log.php"><button type="submit" id="logBtn" class="btn btn-primary">Login</button></a>
        </div>
    </div>
    

    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>